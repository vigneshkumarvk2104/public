import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderlayoutComponent } from './layouts/headerlayout/headerlayout.component'
import { ProfileheaderlayoutComponent } from './layouts/profileheaderlayout/profileheaderlayout.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', loadChildren: 'src/app/modules/home/home.module#HomeModule' },
  { path: 'profile', component:ProfileheaderlayoutComponent, loadChildren: 'src/app/modules/profile/profile.module#ProfileModule' },
  { path: 'college', loadChildren: 'src/app/modules/colleges/colleges.module#CollegesModule' },
  { path: 'course_details', loadChildren: 'src/app/modules/course/course.module#CourseModule' },
  { path: '**',redirectTo: '/home',pathMatch:'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
