import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { PopupComponent } from './popup/popup.component';
import { HeaderlayoutComponent } from './headerlayout/headerlayout.component';
import { ProfileheaderlayoutComponent } from './profileheaderlayout/profileheaderlayout.component';
import { NguCarouselModule } from '@ngu/carousel';
import { NgMaterialMultilevelMenuModule } from 'ng-material-multilevel-menu';
import { RouterModule } from '@angular/router';


@NgModule({
  declarations: [PopupComponent,HeaderlayoutComponent,ProfileheaderlayoutComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NguCarouselModule,
    NgMaterialMultilevelMenuModule,
    RouterModule
  ],
  exports: [
    PopupComponent,
    HeaderlayoutComponent,
    ProfileheaderlayoutComponent
  ]
})
export class LayoutModule { }
