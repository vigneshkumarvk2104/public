import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { ApiService } from 'src/app/core/services/api.service';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-headerlayout',
  templateUrl: './headerlayout.component.html',
  styleUrls: ['./headerlayout.component.css']
})
export class HeaderlayoutComponent implements OnInit {
  courseDetails: any;
  collegeDetails: any;

  constructor(private route: Router, private apiService: ApiService) {
    this.getCourseDetails();
    this.getCollegeDetails();
  }

  ngOnInit() {
  }

  appitem = [
    {
      label: 'Top Courses',
      // items: [
      //   {
      //     label: 'course Name1',
      //     link: '/course_details',
      //   },
      //   {
      //     label: 'course Name2',
      //     items: [
      //       {
      //         label: 'Item 1.2.1',
      //         link: '/item-1-2-1',
      //       },
      //       {
      //         label: 'Item 1.2.2',
      //         items: [
      //           {
      //             label: 'Item 1.2.2.1',
      //             link: 'item-1-2-2-1',
      //           }
      //         ]
      //       }
      //     ]
      //   }
      // ]
    },
    {
      label: 'Popular Specialization',
      items: [
        {
          label: 'Course 1',
          items: [
            {
              label: 'Specialization 1',
              link: '/course_detail_specialization',
            }
          ]
        },
        {
          label: 'course 2',
          link: '/item-2-2',
        }
      ]
    },
    {
      label: 'Top Colleges',
      // link: '/item-3',
      // items: [
      //   {
      //     label: 'college 1',
      //     link: '/college',
      //   }
      // ]
    },
    {
      label: 'College By Locations',
      items: [
        {
          label: 'Location 1',
          link: '/course_name_specialization',
        }
      ]
    },
    {
      label: 'Compare Colleges',
      items: [
        {
          label: 'Compare Colleges',
          link: '/college_comparision',
        }
      ]
    },
    {
      label: 'College Reviews',
      link: '/item-4',
      items: [
        {
          label: 'Item 1.1',
          link: '/item-1-1',
        }
      ]
    },
    {
      label: 'Rank Predictor',
      link: '/item-4',
      items: [
        {
          label: 'Rank Predictor 1',
          link: '/rank_predictor',
        }
      ]
    },
    {
      label: 'School',
      link: '/school',
      items: [
        {
          label: 'Senior secondary school',
          items: [
            {
              label: '11th',
              items: [
                {
                  label: 'PCMB',
                  link: '/school-search-results',
                },
              ]
            },
          ]
        },
        {
          label: 'Primary school',
          items: [
            {
              label: 'Primary school 1',
              link: '/school-single-page',
            },
          ]
        }
      ]
    },
    {
      label: 'Salary Trend Report',
      link: '/item-4',
      items: [
        {
          label: 'Salary Trend Report',
          link: '/salary_trend_report',
        }
      ]
    },
    {
      label: 'Results',
      link: '/item-4',
      items: [
        {
          label: '10th',
          link: '/result',
        },
        {
          label: '12th',
          link: '/result',
        },
        {
          label: 'Enterance Exam',
          link: '/result',
        }
      ]
    },
    {
      label: 'Study Abroad',
      items: [
        {
          label: 'Study Abroad',
          link: '/study-abroad',
        }
      ]
    },
    {
      label: 'Resources',
      link: '/item-4',
      items: [
        {
          label: 'Item 1.1',
          link: '/item-1-1',
        }
      ]
    }
  ];

  getCourseDetails() {
    this.apiService.get('/v1/courses', '').pipe(
      tap(course => {
        this.courseDetails = course.result;
        this.dynamicCategory();
      })
    ).subscribe();
  }

  getCollegeDetails() {
    this.apiService.get('/v1/college/get_college', '').pipe(
      tap(college => {
        this.collegeDetails = college.result;
        this.dynamicCategory();
      })
    ).subscribe();
  }

  dynamicCategory() {
    this.appitem.filter((value) => {
      if (value.label == 'Top Courses') {
        value['items'] = this.courseDetails;
        this.courseDetails.map((values) => {
          values['label'] = values.course_name;
          values['course_id'] = values.id;
          values['nav'] = '/course_details';
        })
      }
      else if (value.label == 'Top Colleges') {
        value['items'] = this.collegeDetails;
        this.collegeDetails.map((values) => {
          values['label'] = values.college_name;
          values['college_id'] = values.id;
          values['nav'] = '/college';
        })
      }
    })
  }

  config = {
    paddingAtStart: true,
    classname: 'my-custom-class',
    listBackgroundColor: 'transparent',
    fontColor: 'white',
    // backgroundColor: 'rgb(208, 241, 239)',
    selectedListFontColor: 'white',
    interfaceWithRoute: true,
  };


  dropdown_visibles: boolean = false;
  mydrops() {
    this.dropdown_visibles = !this.dropdown_visibles
  }

  selectedItem(event) {
    if (event.course_id) {
      let navigationExtras: NavigationExtras = {
        queryParams: {
          course_id: event.course_id
        }
      };
      this.route.navigate([event.nav], navigationExtras);
    }
    else if(event.college_id) {
      let navigationExtras: NavigationExtras = {
        queryParams: {
          college_id: event.college_id
        }
      };
      this.route.navigate([event.nav], navigationExtras);
    }
  }
}
