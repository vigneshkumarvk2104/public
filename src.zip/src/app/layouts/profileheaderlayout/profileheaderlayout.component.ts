import { Component, OnInit,Renderer2, ViewChild, ElementRef } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { Router, NavigationExtras } from '@angular/router';
import { ApiService } from 'src/app/core/services/api.service';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-profileheaderlayout',
  templateUrl: './profileheaderlayout.component.html',
  styleUrls: ['./profileheaderlayout.component.css']
})
export class ProfileheaderlayoutComponent implements OnInit {

  @ViewChild('toggleButton',{static:false}) toggleButton: ElementRef;
  @ViewChild('menu',{static:false}) menu: ElementRef;
  courseDetails: any;
  collegeDetails: any;

  constructor(private renderer: Renderer2, private authService: AuthService, private route: Router, private apiService: ApiService) { 
    this.getCourseDetails();
    this.getCollegeDetails();
  }

  ngOnInit() {
  }
  ngAfterViewInit() {this.renderer.listen('window', 'click',(e:Event)=>{
    console.log(e.target)

      if(e.target !== this.toggleButton.nativeElement && e.target!==this.menu.nativeElement){
          this.dropdown_visible=false;
          console.log("hi")
      }
  });}
  appitems = [
    {
      label: 'Top Courses',
      // items: [
      //   {
      //     label: 'course Name1',
      //     link: '/course_details',
      //   },
      //   {
      //     label: 'course Name2',
      //     items: [
      //       {
      //         label: 'Item 1.2.1',
      //         link: '/item-1-2-1',
      //       },
      //       {
      //         label: 'Item 1.2.2',
      //         items: [
      //           {
      //             label: 'Item 1.2.2.1',
      //             link: 'item-1-2-2-1',
      //           }
      //         ]
      //       }
      //     ]
      //   }
      // ]
    },
    {
      label: 'Popular Specialization',
      items: [
        {
          label: 'Course 1',
          items: [
            {
              label: 'Specialization 1',
              link: '/course_detail_specialization',
            }
          ]
        },
        {
          label: 'course 2',
          link: '/item-2-2',
        }
      ]
    },
    {
      label: 'Top Colleges',
      link: '/item-3',
      items: [
        {
          label: 'college 1',
          link: '/college',
        }
      ]
    },
    {
      label: 'College By Locations',
      items: [
        {
          label: 'Location 1',
          link: '/course_name_specialization',
        }
      ]
    },
    {
      label: 'Compare Colleges',
      link: '/item-4',
      items: [
        {
          label: 'Compare Colleges',
          link: '/college_comparision',
        }
      ]
    },
    {
      label: 'College Reviews',
      link: '/item-4',
      items: [
        {
          label: 'Item 1.1',
          link: '/item-1-1',
        }
      ]
    },
    {
      label: 'Rank Predictor',
      link: '/item-4',
      items: [
        {
          label: 'Rank Predictor 1',
          link: '/rank_predictor',
        }
      ]
    },
    {
      label: 'School',
      link: '/item-4',
      items: [
        {
          label: 'Item 1.1',
          link: '/item-1-1',
        }
      ]
    },
    {
      label: 'Salary Trend Report',
      link: '/item-4',
      items: [
        {
          label: 'Salary Trend Report',
          link: '/salary_trend_report',
        }
      ]
    },
    {
      label: 'Results',
      link: '/item-4',
      items: [
        {
          label: 'After 10th',
          link: '/careers-after-tenth',
        },
        {
          label: 'After 12th',
          link: '/careers-after-twelve',
        },
        {
          label: 'After UG',
          link: '/careers-after-ug',
        },
        {
          label: 'After PG',
          link: '/careers-after-pg',
        }
      ]
    },
    {
      label: 'Study Abroad',
      link: '/item-4',
      items: [
        {
          label: 'Item 1.1',
          link: '/item-1-1',
        }
      ]
    },
    {
      label: 'Resources',
      link: '/item-4',
      items: [
        {
          label: 'Item 1.1',
          link: '/item-1-1',
        }
      ]
    }
  ];

  getCourseDetails() {
    this.apiService.get('/v1/courses', '').pipe(
      tap(course => {
        this.courseDetails = course.result;
        this.dynamicCategory();
      })
    ).subscribe();
  }

  getCollegeDetails() {
    this.apiService.get('/v1/college/get_college', '').pipe(
      tap(college => {
        this.collegeDetails = college.result;
        this.dynamicCategory();
      })
    ).subscribe();
  }

  dynamicCategory() {
    this.appitems.filter((value) => {
      if (value.label == 'Top Courses') {
        value['items'] = this.courseDetails;
        this.courseDetails.map((values) => {
          values['label'] = values.course_name;
          values['course_id'] = values.id;
          values['nav'] = '/course_details';
        })
      }
      else if (value.label == 'Top Colleges') {
        value['items'] = this.collegeDetails;
        this.collegeDetails.map((values) => {
          values['label'] = values.college_name;
          values['college_id'] = values.id;
          values['nav'] = '/college';
        })
      }
    })
  }

  config = {
    paddingAtStart: true,
    classname: 'my-custom-class',
    listBackgroundColor: 'transparent',
    fontColor: 'white',
    // backgroundColor: 'rgb(208, 241, 239)',
    selectedListFontColor: 'white',
  };

  dropdown_visible:boolean=false;
  mydrop(){
      this.dropdown_visible = !this.dropdown_visible
  }

  //vignesh
  logOut(){
    this.authService.logout();
    alert("Logged out successfully")
  }

  selectedItem(event){
    if (event.course_id) {
      let navigationExtras: NavigationExtras = {
        queryParams: {
          course_id: event.course_id
        }
      };
      this.route.navigate([event.nav], navigationExtras);
    }
    else if(event.college_id) {
      let navigationExtras: NavigationExtras = {
        queryParams: {
          college_id: event.college_id
        }
      };
      this.route.navigate([event.nav], navigationExtras);
    }
  }
}
