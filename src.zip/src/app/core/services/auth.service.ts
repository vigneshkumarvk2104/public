import { Injectable } from '@angular/core';
import { of, Observable, } from 'rxjs';
import { ApiService } from './api.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})

export class AuthService {

  constructor(private apiService: ApiService, private router: Router) { }

  login(userId,pwd): Observable<any> {
    return this.apiService.post('/v1/users', {email_id :userId,password:pwd});
  };

  logout() {
    sessionStorage.clear();
    this.router.navigate(['/home']);
    return of(false);
  }

  getToken() {
    return sessionStorage.getItem('token');
  }
}
