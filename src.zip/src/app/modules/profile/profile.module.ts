import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfileRoutingModule } from './profile-routing.module';
import { ProfileComponent } from './profile/profile.component';
import { NgMaterialMultilevelMenuModule } from 'ng-material-multilevel-menu';
import { LayoutModule } from 'src/app/layouts/layout.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [ProfileComponent],
  imports: [
    CommonModule,
    ProfileRoutingModule,
    NgMaterialMultilevelMenuModule,
    // LayoutModule,
    FormsModule
  ]
})
export class ProfileModule { }
