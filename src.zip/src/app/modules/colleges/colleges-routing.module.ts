import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { CollegesComponent } from './colleges/colleges.component';
import { CollegeApplicationComponent } from './college-application/college-application.component';

const routes: Routes = [
  {
    path: '',
    component: CollegesComponent
  },
  {
    path: '',
    children: [
      {
        path: 'college_application',
        component: CollegeApplicationComponent
      }
    ]
  }
]
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class CollegesRoutingModule { }

