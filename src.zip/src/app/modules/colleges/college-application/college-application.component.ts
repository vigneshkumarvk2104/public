import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api.service';
import { tap } from 'rxjs/operators';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-college-application',
  templateUrl: './college-application.component.html',
  styleUrls: ['./college-application.component.css']
})
export class CollegeApplicationComponent implements OnInit {
  collegeInfo: any;
  eduDetails: any;
  selectedFile: File = null;
  courseDetails: any;
  specializationDetails: any;
  url: any;

  public CateOpt = [
    { value: "General", id: 1 },
    { value: "OBC", id: 2 },
    { value: "SC/ST", id: 3 },
    { value: "PH", id: 4 }
  ]

  constructor(private apiService: ApiService, private _sanitizer: DomSanitizer) {
    this.getEduDetails();
    this.getCourseDetails();
    this.getSpecializationDetails();
    this.collegeInfo = {
      "first_name": "",
      "middle_name": "",
      "last_name": "",
      "dob": "",
      "gender": "",
      "stream": "",
      "father_name": "",
      "mother_name": "",
      "temporary_address": "",
      "father_occupation": "",
      "mother_occupation": "",
      "permanent_address": "",
      "mobile_number": "",
      "email_id": "",
      "NRI": "",
      "categories": "",
      "course_id": 1,
      "specialization_id": 1,
      "admin_note": "",
      "exam": [
        {
          "exam_name": "",
          "exam_mark": "",
          "exam_rank": "",
          "information_id": 1
        }
      ],
      "upload": [
        {
          "aadhar_upload": "assets/images/plus.png",
          "tenth_upload": "assets/images/plus.png",
          "twelveth_upload": "assets/images/plus.png",
          "information_id": 1
        }
      ],
      "education": [
        {
          "year_of_passing": "",
          "marks_obtained": "",
          "remarks": "",
          "information_id": 1,
          "education_id": 1
        }
      ]
    }
  }

  getEduDetails() {
    this.apiService.get('/v1/informations/get_education', '').pipe(
      tap(education => {
        this.eduDetails = education.result;
      })
    ).subscribe();
  }

  getCourseDetails() {
    this.apiService.get('/v1/courses', '').pipe(
      tap(course => {
        this.courseDetails = course.result;
      })
    ).subscribe();
  }
  getSpecializationDetails() {
    this.apiService.get('/v1/specialization', '').pipe(
      tap(specialization => {
        this.specializationDetails = specialization.result;
      })
    ).subscribe();
  }

  deleteObj(value,index){
    if(value == "eduInfo"){
      this.collegeInfo.education.splice(index,1);
    }
    else if(value == "examInfo"){
      this.collegeInfo.exam.splice(index,1);
    }
    else if(value == "uploadInfo"){
      this.collegeInfo.upload.splice(index,1);
    }
  }

  addMore(value) {
    if (value == "eduInfo") {
      const eduInfoTemplate = {
        "year_of_passing": "",
        "marks_obtained": "",
        "remarks": "",
        "information_id": 1,
        "education_id": 1
      }
      this.collegeInfo.education.push(eduInfoTemplate);
    }
    else if (value == "examInfo") {
      const examInfoTemplate = {
        "exam_name": "",
        "exam_mark": "",
        "exam_rank": "",
        "information_id": 1
      }
      this.collegeInfo.exam.push(examInfoTemplate);
    }
    else if (value == "uploadInfo") {
      const uploadInfoTemplate = {
        "aadhar_upload": "assets/images/plus.png",
        "tenth_upload": "assets/images/plus.png",
        "twelveth_upload": "assets/images/plus.png",
        "information_id": 1
      }
      this.collegeInfo.upload.push(uploadInfoTemplate);
    }
  }

  onSelectFile(event, index, value) {
    if (event.target.files && event.target.files[0] && event.target.files[0].type == 'image/png') {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]); 
      reader.onload = (event) => { 
        if(value == 'aadhar_upload'){
          this.collegeInfo.upload[index].aadhar_upload = event.target['result']
        }
        else if(value == 'tenth_upload'){
          this.collegeInfo.upload[index].tenth_upload = event.target['result']
        }
        else if(value == 'twelveth_upload'){
          this.collegeInfo.upload[index].twelveth_upload = event.target['result']
        }
      }
    }
    else if(event.target.files[0].type == 'application/pdf'){
      this.collegeInfo.upload[index][value] = 'assets/images/PDF.jpg';
    }
    else{
      alert("Please upload only images or PDF")
    }
  }

  ngOnInit() {
  }

  saveApplication() {
    this.apiService.post('/v1/informations/save_information', this.collegeInfo).pipe(
      tap(res => {
        console.log(res)
        // if(res['Msg'] == "Successfully added"){
        //   alert(res['Msg']);
        // }
      }
      )
    ).subscribe();
  }

}
