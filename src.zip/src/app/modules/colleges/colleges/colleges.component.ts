import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api.service';
import { tap } from 'rxjs/operators';
import { StarRatingComponent } from 'ng-starrating';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-colleges',
  templateUrl: './colleges.component.html',
  styleUrls: ['./colleges.component.css']
})
export class CollegesComponent implements OnInit {
  isShown;
  isShown2;
  isShown3;
  isShown4;
  isShown5;
  isShown6;
  isShown7;
  isShown8;
  isShown9;
  isShown10;
  isShown11;
  collegeDetails: any;

  placement: any;
  placementReview: any;
  infrastructure: any;
  infrastructureReview: any;
  faculty: any;
  facultyReview: any;
  crowd: any;
  crowdReview: any;
  money: any;
  moneyReview: any;
  duration: any;
  durationReview: any;
  checkLogin = sessionStorage.getItem('token');

  serverData: any[] = [];

  constructor(private apiservice: ApiService, private route: ActivatedRoute) {
    this.route.queryParams.subscribe(params => {
      console.log(params);
      this.onload(params.college_id);
    });
  }

  ngOnInit() {
  }

  

  onload(collegeID) {
    let serverData = {
      id: collegeID
    }
    this.apiservice.get('/v1/college/get_collegesinglepage', serverData).pipe(
      tap(collegeDetails => {
        this.collegeDetails = collegeDetails.result[0];
      })
    ).subscribe();
  }

  onRate($event: { oldValue: number, newValue: number, starRating: StarRatingComponent }, name) {
    if (name == 'placement') {
      this.placementReview = $event.newValue;
    }
    else if (name == 'infrastructure') {
      this.infrastructureReview = $event.newValue;
    }
    else if (name == 'faculty') {
      this.facultyReview = $event.newValue;
    }
    else if (name == 'crowd') {
      this.crowdReview = $event.newValue;
    }
    else if (name == 'money') {
      this.moneyReview = $event.newValue;
    }
    else if (name == 'duration') {
      this.durationReview = $event.newValue;
    }
  }

  submitReviewFn() {
    this.serverData.push({
      'label': 'placement',
      'rate': this.placementReview,
      'review': this.placement
    }, {
      'label': 'infrastructure',
      'rate': this.infrastructureReview,
      'review': this.infrastructure
    }, {
      'label': 'faculty',
      'rate': this.facultyReview,
      'review': this.faculty
    }, {
      'label': 'crowd',
      'rate': this.crowdReview,
      'review': this.crowd
    }, {
      'label': 'money',
      'rate': this.moneyReview,
      'review': this.money
    }, {
      'label': 'duration',
      'rate': this.durationReview,
      'review': this.duration
    });
    var giveAlert = false;
    this.serverData.filter((values) => {
      if (values.rate == undefined || values.review == undefined) {
        giveAlert = true;
      }
    })
    if (giveAlert) {
      alert("Please fill all the reviews and ratings");
      this.serverData = [];
    }
    else {
      console.log(this.serverData);
    }
  }

  toTop(section_id) {

    switch (section_id) {

      case ("courses"):
        document.getElementById("courses").scrollIntoView();
        break;

      case ("Reviews"):
        document.getElementById("Reviews").scrollIntoView();
        break;

      case ("admission_criteria"):
        document.getElementById("admission_criteria").scrollIntoView();
        break;

      case ("entrance-exam"):
        document.getElementById("entrance-exam").scrollIntoView();
        break;

      case ("facilities"):
        document.getElementById("facilities").scrollIntoView();
        break;

      case ("gallery"):
        document.getElementById("gallery").scrollIntoView();
        break;

      case ("events"):
        document.getElementById("events").scrollIntoView();
        break;

      case ("scholarships"):
        document.getElementById("scholarships").scrollIntoView();
        break;

      case ("questions-a"):
        document.getElementById("questions-a").scrollIntoView();
        break;

      case ("articles"):
        document.getElementById("articles1").scrollIntoView();
        break;

      default:
        document.getElementById("contacts").scrollIntoView();
        break;
    }
  }

  toggleShow() {
    this.isShown = !this.isShown;
  }

  toggleShow2() {
    this.isShown2 = !this.isShown2;
  }
  toggleShow3() {
    this.isShown3 = !this.isShown3;
  }
  toggleShow4() {
    this.isShown4 = !this.isShown4;
  }
  toggleShow5() {
    this.isShown5 = !this.isShown5;
  }
  toggleShow6() {
    this.isShown6 = !this.isShown6;
  }
  toggleShow7() {
    this.isShown7 = !this.isShown7;
  }
  toggleShow8() {
    this.isShown8 = !this.isShown8;
  }
  toggleShow9() {
    this.isShown9 = !this.isShown9;
  }
  toggleShow10() {
    this.isShown10 = !this.isShown10;
  }
  toggleShow11() {
    this.isShown11 = !this.isShown11;
  }

}
