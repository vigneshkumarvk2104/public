import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CollegesRoutingModule } from './colleges-routing.module';
import { CollegesComponent } from './colleges/colleges.component';
import { CollegeApplicationComponent } from './college-application/college-application.component';
import { RouterModule } from '@angular/router';
import { RatingModule } from 'ng-starrating';
 
@NgModule({
  declarations: [CollegesComponent, CollegeApplicationComponent],
  imports: [
    CommonModule,
    FormsModule,
    CollegesRoutingModule,
    RouterModule,
    RatingModule
  ]
})
export class CollegesModule { }
