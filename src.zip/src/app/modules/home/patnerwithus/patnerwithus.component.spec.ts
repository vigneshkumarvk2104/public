import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatnerwithusComponent } from './patnerwithus.component';

describe('PatnerwithusComponent', () => {
  let component: PatnerwithusComponent;
  let fixture: ComponentFixture<PatnerwithusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatnerwithusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatnerwithusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
