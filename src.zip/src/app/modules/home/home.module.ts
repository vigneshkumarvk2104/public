import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HomeRoutingModule } from './home-routing.module';
import { LayoutModule } from 'src/app/layouts/layout.module';
import { NguCarouselModule } from '@ngu/carousel';
import { HomeComponent } from './home/home.component';
import { PatnerwithusComponent } from './patnerwithus/patnerwithus.component';
import { PatnerwithusCollegeComponent } from './patnerwithus-college/patnerwithus-college.component';

@NgModule({
  declarations: [HomeComponent, PatnerwithusComponent, PatnerwithusCollegeComponent],
  imports: [
    CommonModule,
    FormsModule,
    HomeRoutingModule,
    LayoutModule,
    NguCarouselModule
  ]
})
export class HomeModule { }
