import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatnerwithusCollegeComponent } from './patnerwithus-college.component';

describe('PatnerwithusCollegeComponent', () => {
  let component: PatnerwithusCollegeComponent;
  let fixture: ComponentFixture<PatnerwithusCollegeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatnerwithusCollegeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatnerwithusCollegeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
