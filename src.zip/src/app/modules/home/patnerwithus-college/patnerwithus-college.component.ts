import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api.service';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-patnerwithus-college',
  templateUrl: './patnerwithus-college.component.html',
  styleUrls: ['./patnerwithus-college.component.css']
})
export class PatnerwithusCollegeComponent implements OnInit {
  partnerDetails: any;
  constructor(private apiService: ApiService) {
    this.partnerDetails = {
      "first_name": "",
      "last_name": "",
      "title": "",
      "business_email": "",
      "business_phone_number": "",
      "college_school_name": "",
      "address_line": "",
      "city": "",
      "state": "",
      "zip_code": "",
      "website": "",
      "designation": "",
      "additional_info": "",
      "admin_notes": "",
      "upload": [
        {
          "aadhar_upload": "assets/images/plus.png",
          "tenth_upload": "assets/images/plus.png",
          "twelveth_upload": "assets/images/plus.png"
        }
      ]
    }
  }

  onSelectFile(event, index, value) {
    if (event.target.files && event.target.files[0] && event.target.files[0].type == 'image/png') {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]); 
      reader.onload = (event) => { 
        if(value == 'aadhar_upload'){
          this.partnerDetails.upload[index].aadhar_upload = event.target['result']
        }
        else if(value == 'tenth_upload'){
          this.partnerDetails.upload[index].tenth_upload = event.target['result']
        }
        else if(value == 'twelveth_upload'){
          this.partnerDetails.upload[index].twelveth_upload = event.target['result']
        }
      }
    }
    else if(event.target.files[0].type == 'application/pdf'){
      this.partnerDetails.upload[index][value] = 'assets/images/PDF.jpg';
    }
    else{
      alert("Please upload only images or PDF")
    }
  }

  ngOnInit() {
  }

  deleteObj(value,index){
    if(value == "uploadInfo"){
      this.partnerDetails.upload.splice(index,1);
    }
  }

  addMore(value) {
    if (value == "uploadInfo") {
      const uploadInfoTemplate = {
        "aadhar_upload": "assets/images/plus.png",
        "tenth_upload": "assets/images/plus.png",
        "twelveth_upload": "assets/images/plus.png"
      }
      this.partnerDetails.upload.push(uploadInfoTemplate);
    }
  }

  submit() {
    this.partnerDetails['partner_type'] = 'college/school';
    this.apiService.post('/v1/partners/save_partners', this.partnerDetails).pipe(
      tap(res => {
        if(res['Msg'] == "Successfully added"){
          alert(res['Msg']);
        }
      }
      )
    ).subscribe();
  }

}
