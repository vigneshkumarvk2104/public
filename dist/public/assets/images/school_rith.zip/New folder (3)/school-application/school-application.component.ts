import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-school-application',
  templateUrl: './school-application.component.html',
  styleUrls: ['./school-application.component.css']
})
export class SchoolApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
