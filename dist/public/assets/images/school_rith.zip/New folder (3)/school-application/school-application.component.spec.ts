import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SchoolApplicationComponent } from './school-application.component';

describe('SchoolApplicationComponent', () => {
  let component: SchoolApplicationComponent;
  let fixture: ComponentFixture<SchoolApplicationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchoolApplicationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchoolApplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
