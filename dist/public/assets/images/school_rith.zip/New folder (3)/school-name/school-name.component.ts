import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-school-name',
  templateUrl: './school-name.component.html',
  styleUrls: ['./school-name.component.css']
})
export class SchoolNameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
